/**********************************************/
/*    IAS Assembler - MC 404 - Trabalho 1     */
/* Vitor Alves Mesquita da Silva - RA: 158498 */
/**********************************************/

/* FUNÇÕES */
bool ehDecimal(char campo[], int tam);
bool ehHexadecimal(char campo[], int tam);
void decimal2Hex(char *hex, char *dec);